package com.example.speedpaint

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import kotlin.math.max

class MainActivity : Activity() {
    private var bitmap: Bitmap? = null
    private var resultUri: Uri? = null
    @Volatile private var cancelFlag = false

    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var generate: Button
    private lateinit var cancel: Button
    private lateinit var watch: Button
    private lateinit var share: Button
    private lateinit var bar: ProgressBar
    private lateinit var handCheck: CheckBox
    private lateinit var handInfo: TextView
    private lateinit var seekDur: SeekBar
    private lateinit var seekHand: SeekBar
    private lateinit var seekSpeed: SeekBar
    private lateinit var spStyle: Spinner
    private lateinit var spDir: Spinner
    private lateinit var spPaper: Spinner
    private lateinit var spRatio: Spinner
    private lateinit var spRes: Spinner
    private lateinit var spHold: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spSens: Spinner
    private lateinit var spThick: Spinner

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun spinner(p: LinearLayout, label: String, items: List<String>, sel: Int = 0): Spinner {
        p.addView(TextView(this).apply { text = label; setPadding(0, dp(8), 0, 0) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
        p.addView(sp)
        return sp
    }

    private fun seekRow(p: LinearLayout, label: (Int) -> String, mx: Int, init: Int): SeekBar {
        val tv = TextView(this).apply { text = label(init); setPadding(0, dp(8), 0, 0) }
        val sb = SeekBar(this).apply { max = mx; progress = init }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { tv.text = label(v) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(tv); p.addView(sb)
        return sb
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        val pick = Button(this).apply { text = "Pilih Foto" }
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        col.addView(pick)
        col.addView(preview, LinearLayout.LayoutParams(-1, dp(200)))

        seekDur = seekRow(col, { "Durasi: ${it + 5} detik" }, 55, 10)
        spStyle = spinner(col, "Gaya menggambar", listOf("Ikuti garis, lalu warna", "Langsung warna (menyapu)", "Ikuti garis saja"))
        spDir = spinner(col, "Arah menggambar", listOf("Kiri ke kanan", "Atas ke bawah", "Dari tengah keluar"))
        spPaper = spinner(col, "Latar kertas", listOf("Putih", "Krem", "Papan tulis"))
        spRatio = spinner(col, "Rasio video", listOf("Sesuai foto", "9:16 (Reels/TikTok)", "1:1 (Instagram)", "16:9 (YouTube)"))
        spRes = spinner(col, "Resolusi", listOf("720p", "1080p"))
        spFps = spinner(col, "FPS video", listOf("24 fps", "30 fps", "60 fps"), 1)
        spSens = spinner(col, "Kepekaan garis", listOf("Otomatis (sesuai gambar)", "Lebih sedikit garis", "Lebih banyak garis"))
        spThick = spinner(col, "Ketebalan garis", listOf("Otomatis (sesuai gambar)", "Tipis", "Sedang", "Tebal"))
        spHold = spinner(col, "Tahan hasil akhir", listOf("0 detik", "1 detik", "2 detik", "3 detik"), 1)

        handCheck = CheckBox(this).apply { text = "Tampilkan gambar tangan"; isChecked = true }
        col.addView(handCheck)
        seekHand = seekRow(col, { "Ukuran tangan: ${it + 20}%" }, 80, 35)
        seekSpeed = seekRow(col, { "Kecepatan gerak tangan: x${(it + 5) / 10f}" }, 25, 5)
        handInfo = TextView(this)
        col.addView(handInfo)
        val handBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val loadHandBtn = Button(this).apply { text = "Ganti tangan (PNG)" }
        val resetHandBtn = Button(this).apply { text = "Bawaan" }
        handBtns.addView(loadHandBtn); handBtns.addView(resetHandBtn)
        col.addView(handBtns)

        generate = Button(this).apply { text = "Buat Video Speedpaint"; isEnabled = false }
        cancel = Button(this).apply { text = "Batalkan"; visibility = View.GONE }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { visibility = View.GONE }
        status = TextView(this).apply { gravity = Gravity.CENTER }
        watch = Button(this).apply { text = "Putar Video"; visibility = View.GONE }
        share = Button(this).apply { text = "Bagikan"; visibility = View.GONE }
        listOf(generate, cancel, bar, status, watch, share).forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { addView(col) })
        refreshHandInfo()
        handCheck.setOnCheckedChangeListener { _, on ->
            seekHand.isEnabled = on; seekSpeed.isEnabled = on
            loadHandBtn.isEnabled = on; resetHandBtn.isEnabled = on
        }

        pick.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 1) }
        loadHandBtn.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 2) }
        resetHandBtn.setOnClickListener { File(filesDir, "hand_custom.png").delete(); refreshHandInfo() }
        generate.setOnClickListener { startRender() }
        cancel.setOnClickListener { cancelFlag = true; status.text = "Membatalkan..." }
        watch.setOnClickListener {
            resultUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        share.setOnClickListener {
            resultUri?.let {
                val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, it)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, "Bagikan video"))
            }
        }
    }

    private fun refreshHandInfo() {
        handInfo.text = if (File(filesDir, "hand_custom.png").exists()) "Tangan: gambar pilihan Anda" else "Tangan: bawaan"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 1) {
            bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, _, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            preview.setImageBitmap(bitmap)
            generate.isEnabled = true
            watch.visibility = View.GONE
            share.visibility = View.GONE
        } else if (req == 2) {
            val f = File(filesDir, "hand_custom.png")
            try {
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, bo)
                if (bo.outWidth <= 0) { f.delete(); Toast.makeText(this, "File bukan gambar", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                f.delete(); Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            refreshHandInfo()
        }
    }

    private fun loadHand(): Bitmap? {
        if (!handCheck.isChecked) return null
        val f = File(filesDir, "hand_custom.png")
        if (f.exists()) {
            val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bo)
            val ss = max(1, bo.outWidth / 1600)
            return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = ss })
        }
        val id = resources.getIdentifier("hand", "drawable", packageName)
        return if (id != 0) BitmapFactory.decodeResource(resources, id) else null
    }

    private fun startRender() {
        val bmp = bitmap ?: return
        val secs = seekDur.progress + 5
        val opts = PaintOptions(
            style = spStyle.selectedItemPosition,
            direction = spDir.selectedItemPosition,
            paper = spPaper.selectedItemPosition,
            ratio = spRatio.selectedItemPosition,
            res = if (spRes.selectedItemPosition == 1) 1080 else 720,
            handPct = seekHand.progress + 20,
            handSpeed = (seekSpeed.progress + 5) / 10f,
            holdSec = spHold.selectedItemPosition,
            fps = intArrayOf(24, 30, 60)[spFps.selectedItemPosition],
            sens = spSens.selectedItemPosition,
            thick = spThick.selectedItemPosition
        )
        val hand = loadHand()
        cancelFlag = false
        generate.isEnabled = false
        cancel.visibility = View.VISIBLE
        watch.visibility = View.GONE
        share.visibility = View.GONE
        bar.progress = 0
        bar.visibility = View.VISIBLE
        status.text = "Membuat video..."
        Thread {
            try {
                val tmp = File(cacheDir, "speedpaint.mp4")
                SpeedPaint.render(bmp, secs, tmp, opts, hand, { cancelFlag }) { p -> runOnUiThread { bar.progress = p } }
                if (cancelFlag) {
                    tmp.delete()
                    runOnUiThread { status.text = "Dibatalkan" }
                } else {
                    val cv = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "speedpaint_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SpeedPaint")
                    }
                    val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                    resultUri = uri
                    runOnUiThread {
                        status.text = "Selesai! Tersimpan di Movies/SpeedPaint"
                        watch.visibility = View.VISIBLE
                        share.visibility = View.VISIBLE
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Gagal: ${e.message}" }
            } finally {
                runOnUiThread { generate.isEnabled = true; cancel.visibility = View.GONE; bar.visibility = View.GONE }
            }
        }.start()
    }
}
